﻿namespace TakeHome
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Start = new System.Windows.Forms.Panel();
            this.Register1 = new System.Windows.Forms.Button();
            this.Login1 = new System.Windows.Forms.Button();
            this.Password1 = new System.Windows.Forms.TextBox();
            this.Nama1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Pn_Register = new System.Windows.Forms.Panel();
            this.Regis = new System.Windows.Forms.Button();
            this.Password2 = new System.Windows.Forms.TextBox();
            this.Nama2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.PN_Main = new System.Windows.Forms.Panel();
            this.Withdraw = new System.Windows.Forms.Button();
            this.LogOut1 = new System.Windows.Forms.Button();
            this.PN_Deposit = new System.Windows.Forms.Panel();
            this.PN_Withdraw = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.Withdraw2 = new System.Windows.Forms.TextBox();
            this.LogOut3 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.Deposit2 = new System.Windows.Forms.TextBox();
            this.LogOut2 = new System.Windows.Forms.Button();
            this.Depo1 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.Depo = new System.Windows.Forms.Button();
            this.Balance1 = new System.Windows.Forms.Label();
            this.Saldo = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.Start.SuspendLayout();
            this.Pn_Register.SuspendLayout();
            this.PN_Main.SuspendLayout();
            this.PN_Deposit.SuspendLayout();
            this.PN_Withdraw.SuspendLayout();
            this.SuspendLayout();
            // 
            // Start
            // 
            this.Start.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.Start.Controls.Add(this.Register1);
            this.Start.Controls.Add(this.Login1);
            this.Start.Controls.Add(this.Password1);
            this.Start.Controls.Add(this.Nama1);
            this.Start.Controls.Add(this.label3);
            this.Start.Controls.Add(this.label2);
            this.Start.Controls.Add(this.label1);
            this.Start.Location = new System.Drawing.Point(12, 12);
            this.Start.Name = "Start";
            this.Start.Size = new System.Drawing.Size(374, 338);
            this.Start.TabIndex = 0;
            // 
            // Register1
            // 
            this.Register1.Location = new System.Drawing.Point(120, 264);
            this.Register1.Name = "Register1";
            this.Register1.Size = new System.Drawing.Size(84, 30);
            this.Register1.TabIndex = 7;
            this.Register1.Text = "Register";
            this.Register1.UseVisualStyleBackColor = true;
            this.Register1.Click += new System.EventHandler(this.Register1_Click);
            // 
            // Login1
            // 
            this.Login1.Location = new System.Drawing.Point(120, 217);
            this.Login1.Name = "Login1";
            this.Login1.Size = new System.Drawing.Size(84, 30);
            this.Login1.TabIndex = 6;
            this.Login1.Text = "Login";
            this.Login1.UseVisualStyleBackColor = true;
            this.Login1.Click += new System.EventHandler(this.Login1_Click);
            // 
            // Password1
            // 
            this.Password1.Location = new System.Drawing.Point(120, 170);
            this.Password1.Name = "Password1";
            this.Password1.Size = new System.Drawing.Size(134, 22);
            this.Password1.TabIndex = 5;
            // 
            // Nama1
            // 
            this.Nama1.Location = new System.Drawing.Point(120, 132);
            this.Nama1.Name = "Nama1";
            this.Nama1.Size = new System.Drawing.Size(134, 22);
            this.Nama1.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Comic Sans MS", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(39, 170);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 18);
            this.label3.TabIndex = 3;
            this.label3.Text = "Password";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(37, 132);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 18);
            this.label2.TabIndex = 2;
            this.label2.Text = "Username";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(113, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(141, 39);
            this.label1.TabIndex = 1;
            this.label1.Text = "UC BANK";
            // 
            // Pn_Register
            // 
            this.Pn_Register.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.Pn_Register.Controls.Add(this.Regis);
            this.Pn_Register.Controls.Add(this.Password2);
            this.Pn_Register.Controls.Add(this.Nama2);
            this.Pn_Register.Controls.Add(this.label4);
            this.Pn_Register.Controls.Add(this.label5);
            this.Pn_Register.Controls.Add(this.label6);
            this.Pn_Register.Location = new System.Drawing.Point(12, 356);
            this.Pn_Register.Name = "Pn_Register";
            this.Pn_Register.Size = new System.Drawing.Size(374, 338);
            this.Pn_Register.TabIndex = 8;
            this.Pn_Register.Visible = false;
            // 
            // Regis
            // 
            this.Regis.Location = new System.Drawing.Point(120, 230);
            this.Regis.Name = "Regis";
            this.Regis.Size = new System.Drawing.Size(84, 30);
            this.Regis.TabIndex = 7;
            this.Regis.Text = "Register";
            this.Regis.UseVisualStyleBackColor = true;
            this.Regis.Click += new System.EventHandler(this.Regis_Click);
            // 
            // Password2
            // 
            this.Password2.Location = new System.Drawing.Point(120, 170);
            this.Password2.Name = "Password2";
            this.Password2.Size = new System.Drawing.Size(134, 22);
            this.Password2.TabIndex = 5;
            // 
            // Nama2
            // 
            this.Nama2.Location = new System.Drawing.Point(120, 132);
            this.Nama2.Name = "Nama2";
            this.Nama2.Size = new System.Drawing.Size(134, 22);
            this.Nama2.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Comic Sans MS", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(39, 170);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 18);
            this.label4.TabIndex = 3;
            this.label4.Text = "Password";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Comic Sans MS", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(37, 132);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 18);
            this.label5.TabIndex = 2;
            this.label5.Text = "Username";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label6.Location = new System.Drawing.Point(113, 46);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(141, 39);
            this.label6.TabIndex = 1;
            this.label6.Text = "UC BANK";
            // 
            // PN_Main
            // 
            this.PN_Main.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.PN_Main.Controls.Add(this.Withdraw);
            this.PN_Main.Controls.Add(this.LogOut1);
            this.PN_Main.Controls.Add(this.Depo);
            this.PN_Main.Controls.Add(this.Balance1);
            this.PN_Main.Controls.Add(this.Saldo);
            this.PN_Main.Controls.Add(this.label9);
            this.PN_Main.Location = new System.Drawing.Point(392, 12);
            this.PN_Main.Name = "PN_Main";
            this.PN_Main.Size = new System.Drawing.Size(374, 338);
            this.PN_Main.TabIndex = 9;
            this.PN_Main.Visible = false;
            // 
            // Withdraw
            // 
            this.Withdraw.Location = new System.Drawing.Point(132, 270);
            this.Withdraw.Name = "Withdraw";
            this.Withdraw.Size = new System.Drawing.Size(84, 30);
            this.Withdraw.TabIndex = 8;
            this.Withdraw.Text = "Withdraw";
            this.Withdraw.UseVisualStyleBackColor = true;
            this.Withdraw.Click += new System.EventHandler(this.Withdraw_Click);
            // 
            // LogOut1
            // 
            this.LogOut1.Location = new System.Drawing.Point(251, 88);
            this.LogOut1.Name = "LogOut1";
            this.LogOut1.Size = new System.Drawing.Size(84, 30);
            this.LogOut1.TabIndex = 8;
            this.LogOut1.Text = "Log Out";
            this.LogOut1.UseVisualStyleBackColor = true;
            this.LogOut1.Click += new System.EventHandler(this.LogOut1_Click);
            // 
            // PN_Deposit
            // 
            this.PN_Deposit.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.PN_Deposit.Controls.Add(this.Deposit2);
            this.PN_Deposit.Controls.Add(this.LogOut2);
            this.PN_Deposit.Controls.Add(this.Depo1);
            this.PN_Deposit.Controls.Add(this.label7);
            this.PN_Deposit.Controls.Add(this.label10);
            this.PN_Deposit.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.PN_Deposit.Location = new System.Drawing.Point(392, 356);
            this.PN_Deposit.Name = "PN_Deposit";
            this.PN_Deposit.Size = new System.Drawing.Size(374, 338);
            this.PN_Deposit.TabIndex = 10;
            this.PN_Deposit.Visible = false;
            // 
            // PN_Withdraw
            // 
            this.PN_Withdraw.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.PN_Withdraw.Controls.Add(this.label13);
            this.PN_Withdraw.Controls.Add(this.label12);
            this.PN_Withdraw.Controls.Add(this.Withdraw2);
            this.PN_Withdraw.Controls.Add(this.LogOut3);
            this.PN_Withdraw.Controls.Add(this.button3);
            this.PN_Withdraw.Controls.Add(this.label8);
            this.PN_Withdraw.Controls.Add(this.label11);
            this.PN_Withdraw.Location = new System.Drawing.Point(772, 12);
            this.PN_Withdraw.Name = "PN_Withdraw";
            this.PN_Withdraw.Size = new System.Drawing.Size(374, 338);
            this.PN_Withdraw.TabIndex = 11;
            this.PN_Withdraw.Visible = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(64, 195);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(218, 28);
            this.label13.TabIndex = 10;
            this.label13.Text = "Uang yang mau diambil";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(115, 152);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(46, 28);
            this.label12.TabIndex = 10;
            this.label12.Text = "Rp. ";
            // 
            // Withdraw2
            // 
            this.Withdraw2.Location = new System.Drawing.Point(105, 245);
            this.Withdraw2.Name = "Withdraw2";
            this.Withdraw2.Size = new System.Drawing.Size(149, 22);
            this.Withdraw2.TabIndex = 9;
            // 
            // LogOut3
            // 
            this.LogOut3.Location = new System.Drawing.Point(251, 88);
            this.LogOut3.Name = "LogOut3";
            this.LogOut3.Size = new System.Drawing.Size(84, 30);
            this.LogOut3.TabIndex = 8;
            this.LogOut3.Text = "Log Out";
            this.LogOut3.UseVisualStyleBackColor = true;
            this.LogOut3.Click += new System.EventHandler(this.LogOut3_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(132, 273);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(84, 30);
            this.button3.TabIndex = 7;
            this.button3.Text = "Withdraw";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.Withdraw1_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(26, 152);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(81, 28);
            this.label8.TabIndex = 3;
            this.label8.Text = "Balance";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label11.Location = new System.Drawing.Point(113, 46);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(141, 39);
            this.label11.TabIndex = 1;
            this.label11.Text = "UC BANK";
            // 
            // Deposit2
            // 
            this.Deposit2.Location = new System.Drawing.Point(105, 183);
            this.Deposit2.Name = "Deposit2";
            this.Deposit2.Size = new System.Drawing.Size(149, 22);
            this.Deposit2.TabIndex = 9;
            // 
            // LogOut2
            // 
            this.LogOut2.Location = new System.Drawing.Point(251, 88);
            this.LogOut2.Name = "LogOut2";
            this.LogOut2.Size = new System.Drawing.Size(84, 30);
            this.LogOut2.TabIndex = 8;
            this.LogOut2.Text = "Log Out";
            this.LogOut2.UseVisualStyleBackColor = true;
            this.LogOut2.Click += new System.EventHandler(this.LogOut2_Click);
            // 
            // Depo1
            // 
            this.Depo1.Location = new System.Drawing.Point(132, 220);
            this.Depo1.Name = "Depo1";
            this.Depo1.Size = new System.Drawing.Size(84, 30);
            this.Depo1.TabIndex = 7;
            this.Depo1.Text = "Deposit";
            this.Depo1.UseVisualStyleBackColor = true;
            this.Depo1.Click += new System.EventHandler(this.Deposit1_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label7.Location = new System.Drawing.Point(100, 142);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(154, 28);
            this.label7.TabIndex = 3;
            this.label7.Text = "Jumlah Deposit";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label10.Location = new System.Drawing.Point(113, 46);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(141, 39);
            this.label10.TabIndex = 1;
            this.label10.Text = "UC BANK";
            // 
            // Depo
            // 
            this.Depo.Location = new System.Drawing.Point(132, 220);
            this.Depo.Name = "Depo";
            this.Depo.Size = new System.Drawing.Size(84, 30);
            this.Depo.TabIndex = 7;
            this.Depo.Text = "Deposit";
            this.Depo.UseVisualStyleBackColor = true;
            this.Depo.Click += new System.EventHandler(this.Depo_Click);
            // 
            // Balance1
            // 
            this.Balance1.AutoSize = true;
            this.Balance1.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Balance1.Location = new System.Drawing.Point(39, 170);
            this.Balance1.Name = "Balance1";
            this.Balance1.Size = new System.Drawing.Size(81, 28);
            this.Balance1.TabIndex = 3;
            this.Balance1.Text = "Balance";
            // 
            // Saldo
            // 
            this.Saldo.AutoSize = true;
            this.Saldo.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Saldo.Location = new System.Drawing.Point(141, 170);
            this.Saldo.Name = "Saldo";
            this.Saldo.Size = new System.Drawing.Size(46, 28);
            this.Saldo.TabIndex = 2;
            this.Saldo.Text = "Rp. ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label9.Location = new System.Drawing.Point(95, 43);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(141, 39);
            this.label9.TabIndex = 1;
            this.label9.Text = "UC BANK";
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1152, 706);
            this.Controls.Add(this.PN_Withdraw);
            this.Controls.Add(this.PN_Main);
            this.Controls.Add(this.PN_Deposit);
            this.Controls.Add(this.Pn_Register);
            this.Controls.Add(this.Start);
            this.Name = "Login";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Login_Load);
            this.Start.ResumeLayout(false);
            this.Start.PerformLayout();
            this.Pn_Register.ResumeLayout(false);
            this.Pn_Register.PerformLayout();
            this.PN_Main.ResumeLayout(false);
            this.PN_Main.PerformLayout();
            this.PN_Deposit.ResumeLayout(false);
            this.PN_Deposit.PerformLayout();
            this.PN_Withdraw.ResumeLayout(false);
            this.PN_Withdraw.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel Start;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Register1;
        private System.Windows.Forms.Button Login1;
        private System.Windows.Forms.TextBox Password1;
        private System.Windows.Forms.TextBox Nama1;
        private System.Windows.Forms.Panel Pn_Register;
        private System.Windows.Forms.Button Regis;
        private System.Windows.Forms.TextBox Password2;
        private System.Windows.Forms.TextBox Nama2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel PN_Main;
        private System.Windows.Forms.Button Withdraw;
        private System.Windows.Forms.Button LogOut1;
        private System.Windows.Forms.Button Depo;
        private System.Windows.Forms.Label Balance1;
        private System.Windows.Forms.Label Saldo;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel PN_Deposit;
        private System.Windows.Forms.Button LogOut2;
        private System.Windows.Forms.Button Depo1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox Deposit2;
        private System.Windows.Forms.Panel PN_Withdraw;
        private System.Windows.Forms.TextBox Withdraw2;
        private System.Windows.Forms.Button LogOut3;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
    }
}

