﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Odbc;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TakeHome
{
    public partial class Login : Form
    {
        DataTable Bank = new DataTable();
        bool loggedIn = false;
        string currentUser = "";
        int Registerrr = 0;
        private void Login_Load(object sender, EventArgs e)
        {
            Bank.Columns.Add("Username");
            Bank.Columns.Add("Password");
            Bank.Columns.Add("Balance", typeof(decimal));
        }
        public Login()
        {
            InitializeComponent();
        }

        private void Register1_Click(object sender, EventArgs e)
        {
            Start.Visible = false;
            Pn_Register.Visible = true;
        }

        private void Regis_Click(object sender, EventArgs e)
        {
            string username = Nama2.Text;
            string password = Password2.Text;
            decimal balance = 0;

            // Check if the username is already taken
            foreach (DataRow row in Bank.Rows)
            {
                if (row["Username"].ToString() == username)
                {
                    MessageBox.Show("Username sudah terpakai");
                    return;
                }
            }

            Bank.Rows.Add(username, password, balance);

            Registerrr++;
            Pn_Register.Visible = false;
            Start.Visible = true;
        }

        private void Login1_Click(object sender, EventArgs e)
        {
            string enteredUsername = Nama1.Text;
            string enteredPassword = Password1.Text;

            // Check if the user exists in the DataTable
            foreach (DataRow row in Bank.Rows)
            {
                string storedUsername = row["Username"].ToString();
                string storedPassword = row["Password"].ToString();

                if (storedUsername == enteredUsername)
                {
                    if (storedPassword == enteredPassword)
                    {
                        loggedIn = true;
                        currentUser = enteredUsername;
                        MessageBox.Show("Login berhasil!");
                        Start.Visible = false;
                        PN_Main.Visible = true;
                        UpdateBalanceLabel();
                    }
                    else
                    {
                        MessageBox.Show("Pasword salah");
                    }
                }
                else
                {
                    MessageBox.Show("Username Tidak ada");
                }
            }
            if (Registerrr == 0)
            {
                MessageBox.Show("Belum ada akun buat dahulu");
            }
        }

        private void Depo_Click(object sender, EventArgs e)
        {
            PN_Main.Visible = false;
            PN_Deposit.Visible = true;
        }

        private void Deposit1_Click(object sender, EventArgs e)
        {
            decimal depositAmount = decimal.Parse(Deposit2.Text);
            foreach (DataRow row in Bank.Rows)
            {
                if (row["Username"].ToString() == currentUser)
                {
                    row["Balance"] = (decimal)row["Balance"] + depositAmount;
                    UpdateBalanceLabel();
                }
            }
            PN_Deposit.Visible = false;
            PN_Main.Visible = true;
        }

        private void Withdraw_Click(object sender, EventArgs e)
        {
            PN_Main.Visible = false;
            PN_Withdraw.Visible = true;
        }

        private void Withdraw1_Click(object sender, EventArgs e)
        {
            decimal withdrawAmount = decimal.Parse(Withdraw2.Text);
            foreach (DataRow row in Bank.Rows)
            {
                if (row["Username"].ToString() == currentUser)
                {
                    if ((decimal)row["Balance"] >= withdrawAmount)
                    {
                        row["Balance"] = (decimal)row["Balance"] - withdrawAmount;
                        UpdateBalanceLabel();
                    }
                    else
                    {
                        MessageBox.Show("Saldo tidak cukup");
                    }
                }
            }
            PN_Withdraw.Visible = false;
            PN_Main.Visible = true;
        }

        private void LogOut1_Click(object sender, EventArgs e)
        {
            PN_Main.Visible = false;
            Start.Visible = true;
            loggedIn = false;
            currentUser = "";
        }

        private void LogOut2_Click(object sender, EventArgs e)
        {
            PN_Deposit.Visible = false;
            Start.Visible = true;
            loggedIn = false;
            currentUser = "";
        }

        private void LogOut3_Click(object sender, EventArgs e)
        {
            PN_Deposit.Visible = false;
            Start.Visible = true;
            loggedIn = false;
            currentUser = "";
        }

        private void UpdateBalanceLabel()
        {
            foreach (DataRow row in Bank.Rows)
            {
                if (row["Username"].ToString() == currentUser)
                {
                    Saldo.Text = "Saldo: " + ((decimal)row["Balance"]).ToString("N0");
                }
            }
        }
    }
}
